class User < ActiveRecord::Base
end

class Deck< ActiveRecord::Base
end 

class Round < ActiveRecord::Base
end

class Question < ActiveRecord::Base
end 

class Answer < ActiveRecord::Base
end 

class RoundQuestion < ActiveRecord::Base
end