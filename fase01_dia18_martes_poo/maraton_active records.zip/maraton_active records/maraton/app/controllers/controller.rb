class Controller 
  def initialize
    @view = View.new
    index
  end

  def index
    input = @view.index
    #menu_register(input)
    users = User.all
 
    case input
      when "1" then menu_register(input)
      when "2" 
        p input = @view.signup_menu 
        signup_user(input)
      # when "administrator_menu" then administrator_menu(selection)
      # when "all" then  all(selection)
      # when "add_flight" then  add_flight(selection, args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8])
      # when "customer" then customer(selection)
      
    end
   
 # p input = @view.index
    # menu_register(input)


  end

  def menu_register(input_user)
    if input_user.to_i == 1
       #@view.register
       new_user_inputs = @view.register
       signup(new_user_inputs)
    end

  
  end
  #introduce to database a data from new user
  def signup(new_user)  
    new_user.each_with_index do |value, index|
      if index == 0
        User.create do |u|
          u.name = new_user[0]
          u.password = new_user[1]
          u.email = new_user[2]
        end
      end
    end
    p "Te has registrado correctamente"
    #@view.signup_menu
     new_signup_inputs = @view.signup_menu#(new_user)
     signup_user(new_signup_inputs)

  end

  def signup_user(signup)
     p " desde la opción dos del menu"

    #p signup
    p "hola"
    #p new_signup_inputs = @view.signup_menu#(new_user)
    

  end

  def complete
  end
end
