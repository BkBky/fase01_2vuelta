class View
	# Recuerda que la única responsabilidad de la vista es desplegar data al usuario
  # Los siguientes métodos son sólo un ejemplo:
  
	def index
    puts"\n\n********************************" 
    puts "      Bienvenido a Maratón     "
    puts"********************************" 
    puts "Escoje una opción:"
    puts "1. Registrarse"
    puts "2. Signup de usuario"
    puts "3. Ver Scores"
    puts "4. Jugar"
    puts "5. Salir\n\n"

    puts "Si aún note has registrado, tendrás que hacerlo para poder jugar\n\n\n"
    input_user = gets.chomp
	end

  def register
    puts"\n\n********************************" 
    puts "      Registro de usuario    "
    puts"********************************" 
    puts "ingresa tu Nombre"
    input_user_name = gets.chomp
    puts "Ingresa tu email"
    input_user_email = gets.chomp
    puts "Ingresa tu password"
    input_user_pass = gets.chomp
    new_user = [input_user_name, input_user_email, input_user_pass] 
  end

  def signup_menu#(new_user1)
    
    #puts new_user1

    puts"\n\n********************************" 
    puts "      Signup de usuario    "
    puts"********************************" 

    puts "ingresa tu nombre"
    input_signup_name = gets.chomp
    puts "ingresa tu password"
    input_signup_pass = gets.chomp
    signup = [input_signup_name, input_signup_pass]
    #signup_user(signup)
  end

  def update
  end

	def error
	end
end
